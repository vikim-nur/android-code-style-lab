# Пробный комплект форматирования 0.2.0-candidate.1

Внутри: JAR наших правил для ktlint 1.8.0, два конфига, учебный вход и готовые результаты. Правила командой ещё не утверждены. Форматируйте отдельную копию, не исходники приложения.

- config/nur-reference.editorconfig — A по эталону, max 140, включены 6 наших правил.
- config/ktlint-official.editorconfig — Б, штатный ktlint_official, max 120, nur отключён.
- nur-style-rules-0.2.0-candidate.1.jar — расширение, а не самостоятельный запускаемый formatter.
- manifest.json — SHA256 JAR, конфигов и исходников правил в репозитории. Исходники/Gradle wrapper в этот ZIP не входят.
- examples/input, examples/nur-reference, examples/ktlint-official — учебный вход и результаты двух профилей.
- reference-coverage.md — точные границы 23 областей оформления.

## Проверка в терминале

Нужен JDK 17+ и отдельно CLI ktlint-1.8.0-all.jar. Его нет в архиве. Замените /полный/путь/к/ktlint-1.8.0-all.jar на свой абсолютный путь. Команды ниже выполняются из распакованной папки:

```sh
mkdir trial-A
cp config/nur-reference.editorconfig trial-A/.editorconfig
cp examples/input/*.kt trial-A/
cd trial-A
java -jar /полный/путь/к/ktlint-1.8.0-all.jar --ruleset=../nur-style-rules-0.2.0-candidate.1.jar --format '*.kt'
java -jar /полный/путь/к/ktlint-1.8.0-all.jar --ruleset=../nur-style-rules-0.2.0-candidate.1.jar '*.kt'
```

Для Б создайте отдельную trial-B и скопируйте config/ktlint-official.editorconfig как .editorconfig. Тот же JAR можно оставить: в Б nur отключён. Не смешивайте конфиги и результаты в одной папке.

## В Android Studio

Нужен совместимый IDE-плагин ktlint с движком 1.8.0. В отдельном тестовом проекте выбранный конфиг поместите в корень как .editorconfig, JAR добавьте в Ruleset JARs и включите Attach to IntelliJ format. Наши проверки загрузчика/движка прошли; работа нового JAR через реальный шорткат пока не подтверждена. Произвольный встроенный formatter Studio сам по себе не равен ktlint.

[Сравнение и выбор команды](https://vikim-nur.github.io/android-code-style-lab/comparison/)

[Отчёт о проверках и ограничениях](https://vikim-nur.github.io/android-code-style-lab/docs/validation-report.html)

[Исходники, сборка и транспортный Gradle-прототип](https://github.com/vikim-nur/android-code-style-lab)
